CFUpdate

Install JWP machines firmware to compact flash card

Available in Italian and English languages
Run the installer on your Windows machine