PVStat

View alarm files from JWP machines
Italian language only

Installation:
Just copy the PVStat folder to your Windows machine and run PVStat.exe
